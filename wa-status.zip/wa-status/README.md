![swagger-application-programming-interface-representational-state-transfer-openapi-specification-logo-whatsapp-status-cartoon-image-691e5a14f757f06d7b7293dea117c32c](https://raw.githubusercontent.com/frmdeveloper/whatsapp-status-reader/main/swagger-application-programming-interface-representational-state-transfer-openapi-specification-logo-whatsapp-status-cartoon-image-691e5a14f757f06d7b7293dea117c32c.png)
<h1 align="center">whatsapp status reader</h1>

Tandai status sebagai telah dilihat
![contoh1](https://raw.githubusercontent.com/frmdeveloper/whatsapp-status-reader/main/IMG-20220808-WA0227.jpg)

___
sebenarnya ini gk guna sih
